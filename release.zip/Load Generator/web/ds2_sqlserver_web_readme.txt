ds2_mysql_web_readme.txt

The SQL Server DVD Store currently has one web application interface, using ASPX

For the ds2webdriver program and source, see ./ds2/drivers

Directories
-----------
./ds2/sqlserverds2/web
./ds2/sqlserverds2/web/aspx        aspx pages 

<dave_jaffe@dell.com> and <tmuirhead@vmware.com>  7/5/05
